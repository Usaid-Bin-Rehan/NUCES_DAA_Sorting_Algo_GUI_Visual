import { createRandomArray } from "./Visualizer.js";
import {bubbleSort , bucketSort , countSort ,quickSort, insertionSort, mergeSort, heapSort, radixSort, MQS} from "../Algos/Algos.js";

//Screen Settings
window.speedFactor = 100;
window.max = 100;
window.heightFactor = (4 / max) * 100;
console.log("height", heightFactor);
window.bars = document.getElementsByClassName("bar");

let randomize_array = document.getElementById("randomize_array_btn");
let sort_btn = document.getElementById("sort_btn");
let bars_container = document.getElementById("bars_container");
let select_algo = document.getElementById("algo");
let slider = document.getElementById("slider");
let length_input = document.getElementById("length");
let numOfBars = 50;
let unsorted_array = new Array(numOfBars);
let file_input = document.getElementById("file");
let algo = "";
let out=document.getElementById("out")

file_input.addEventListener("change", function () {
    let file = file_input.files[0];
    let reader = new FileReader();
    reader.addEventListener("load", function () {
        let buffer = reader.result.split(",");  ///\s+/
        var numberArray = buffer.map(Number);
        console.log(numberArray);
        unsorted_array = numberArray;
        numOfBars = 50;
        bars_container.innerHTML = "";
        renderBars(numberArray);
    });
    reader.readAsText(file, "utf-8");
});

slider.addEventListener("change", function () {
    speedFactor = 150 - slider.value;
    console.log(speedFactor);
});

length_input.addEventListener("input", function () {
    numOfBars = length_input.value;
    bars_container.innerHTML = "";
    unsorted_array = createRandomArray(numOfBars, 1, max);
    renderBars(unsorted_array);
});


select_algo.addEventListener("change", function () {
    if (select_algo.value === "range") {
        window.location = "Engine/range.html";
    } else algo = select_algo.value;
});


select_algo.addEventListener("change", function () {
    if (select_algo.value === "time") {
        window.location = "Engine/time.html";
    } else algo = select_algo.value;
});

document.addEventListener("DOMContentLoaded", function () {
    unsorted_array = createRandomArray(numOfBars, 1, max);
    renderBars(unsorted_array);
});

function renderBars(array) {
    console.log("file array", array, numOfBars);
    for (let i = 0; i < numOfBars; i++) {
        let bar = document.createElement("div");
        bar.classList.add("bar");
        bar.style.height = array[i] * heightFactor + "px";
        bars_container.appendChild(bar);
    }
}

randomize_array.addEventListener("click", function () {
    unsorted_array = createRandomArray(numOfBars, 1, max);
    bars_container.innerHTML = "";
    renderBars(unsorted_array);
});

sort_btn.addEventListener("click", function () {
    let start,end;
    switch (algo) {
        case "bubble":
            start = performance.now();
            bubbleSort(unsorted_array);
            end = performance.now();
            out.innerHTML = `${end - start} milliseconds`;
            break;
        case "merge":
            mergeSort(unsorted_array, 0, unsorted_array.length - 1);
            break;
        case "heap":
            heapSort(unsorted_array);
            break;
        case "insertion":
            insertionSort(unsorted_array);
            break;
        case "quick":
            quickSort(unsorted_array, 0, unsorted_array.length - 1);
            break;
        case "count":
            countSort(unsorted_array);
            break;
        case "radix":
            radixSort(unsorted_array, unsorted_array.length);
            break;
        case "bucket":
            bucketSort(unsorted_array, 5);
            break;
        case "MQS":
            MQS(unsorted_array, 0, unsorted_array.length - 1);
            break;
            
        default:
            bubbleSort(unsorted_array);
            break;
    }
});