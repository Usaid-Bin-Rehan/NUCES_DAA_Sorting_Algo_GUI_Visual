import {swap} from '../Engine/Visualizer.js'
import { sleep } from "../Engine/Visualizer.js";
import { colorChange } from "../Engine/Visualizer.js";

//BubbleSort
export async function bubbleSort(array) {
console.time()
    for (let i = 0; i < array.length; i++) {
        for (let j = 0; j < array.length - i - 1; j++) {
            if (array[j] > array[j + 1]) 
                await swap(array,j,j+1);
        }
    }

    console.timeEnd()
    return array;
}

//BucketSort

async function insertionSorter(array) {

    var length = array.length;

    for (var i = 1; i < length; i++) {
        var temp = array[i];
        for (var j = i - 1; j >= 0 && array[j] > temp; j--) {
            array[j + 1] = array[j];
        }
        array[j + 1] = temp;
    }
    return new Promise((res) => {
        res();
    });
}

export async function bucketSort(array, bucketSize) {
    console.time()

    if (array.length === 0) {
        return array;
    }

    var i,
        minValue = array[0],
        maxValue = array[0],
        bucketSize = bucketSize || 5;

    array.forEach(function (currentVal) {
        if (currentVal < minValue) {
            minValue = currentVal;
        } else if (currentVal > maxValue) {
            maxValue = currentVal;
        }
    });

    var bucketCount = Math.floor((maxValue - minValue) / bucketSize) + 1;
    var allBuckets = new Array(bucketCount);

    for (i = 0; i < allBuckets.length; i++) {
        allBuckets[i] = [];
    }
    array.forEach(function (currentVal) {
        allBuckets[Math.floor((currentVal - minValue) / bucketSize)].push(
            currentVal
        );
    });

    array.length = 0;
    for (let i = 0; i < allBuckets.length; i++) {
        await insertionSorter(allBuckets[i]);
        for (let j = 0; j < allBuckets[i].length; j++) {
            let index = array.push(allBuckets[i][j]) - 1;
            bars[index].style.height = array[index] * heightFactor + "px";
            bars[index].style.backgroundColor = "#0040FF";
            await sleep(speedFactor);
            bars[index].style.backgroundColor = "powderblue";
        }
    }
        console.timeEnd()

    return array;
}


//CountSort
export  async function countSort(inputArr) {
    console.time()

    let n = inputArr.length;
    let k = Math.max(...inputArr);
    let t;

    const temp = new Array(k + 1).fill(0);

    for (let i = 0; i < n; i++) {
        t = inputArr[i];
        temp[t]++;
    }
    for (let i = 1; i <= k; i++) {
        temp[i] = temp[i] + temp[i - 1];
    }

    const outputArr = new Array(n).fill(0);

    for (let i = n - 1; i >= 0; i--) {
        let t = inputArr[i];
        outputArr[temp[t] - 1] = t;
        bars[temp[t] - 1].style.height = t * heightFactor + "px";
        bars[temp[t] - 1].style.backgroundColor = "#0040FF";
        await sleep(speedFactor);
        bars[temp[t] - 1].style.backgroundColor = "powderblue";
        temp[t] = temp[t] - 1;
    }
        console.timeEnd()

    return outputArr;
}

//QuickSort
async function partition(arr, low, high) {
    let pivot = arr[high];
    let i = low - 1;
    console.log(low, high);
    console.log(pivot - 1);
    bars[high].style.backgroundColor = "red";
    for (let j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            await swap(arr, i, j);
        }
    }
    await swap(arr, i + 1, high);
    bars[high].style.backgroundColor = "powderblue";
    return new Promise((resolve) => {
        resolve(i + 1);
    });
}

export  async function quickSort(arr, low, high) {
        console.time()

    if (low < high) {
        let pi = await partition(arr, low, high);
        await quickSort(arr, low, pi - 1);
        await quickSort(arr, pi + 1, high);
    }
    console.timeEnd()
    return new Promise((res) => res());
}

//InsertionSort
export async function insertionSort(array) {
    for (let i = 1; i < array.length; i++) {
        let key = array[i];
        let j = i - 1;
        while (j >= 0 && array[j] > key) {
            array[j + 1] = array[j];
            bars[j + 1].style.height = array[j + 1] * heightFactor + "px";
            bars[j + 1].style.backgroundColor = "red";
            await sleep(speedFactor);
            bars[j + 1].style.backgroundColor = "powderblue";
            j = j - 1;
        }
        array[j + 1] = key;
        await colorChange(array, j + 1);
    }
    return new Promise((resolve) => {
        resolve(array);
    });
}


//Merge Sort
async function merge(arr, left,mid, right)
{
    let n1 = mid-left+1;
    var n2 = right-mid;
 
    let leftTemp=new Array(n1);
    let rightTemp=new Array(n2);
 
    for (let i = 0; i < n1; i++)
        leftTemp[i] = arr[left + i];
    for (let j = 0; j < n2; j++)
        rightTemp[j] = arr[mid + 1 + j];
 
    let i=0,j=0,k=left;
 
    while (i < n1 && j < n2) {
        if (leftTemp[i] <= rightTemp[j]) {
            arr[k] = leftTemp[i];
            i++;
        }
        else {
            arr[k] = rightTemp[j];
            j++;
        }
        await colorChange(arr,k);
        k++;
    }
    while (i < n1) {
        arr[k] = leftTemp[i];
        await colorChange(arr,k);
        i++;
        k++; 
    }
    while (j < n2) {
        arr[k] = rightTemp[j];
        await colorChange(arr,k);
        j++;
        k++;
    }
    return new Promise((resolve)=>{resolve()})
}

export async function mergeSort(arr,left, right){
    if(left>=right){
        return;
    }
    var mid =left+ parseInt((right-left)/2);
    await mergeSort(arr,left,mid);
    await mergeSort(arr,mid+1,right);
    await merge(arr,left,mid,right);
    return new Promise((resolve)=>{resolve()})
}

//Heap Sort
export async function heapSort(array) {
    for (let i = Math.floor(array.length / 2); i >= 0; i--) {
      await heapify(array, array.length, i);
    }
    for (let i = array.length - 1; i >= 0; i--) {
      await swap(array, 0, i, bars);
      await heapify(array, i, 0);
    }
    return array;
}
  
async function heapify(array, n, i) {
    let bars = document.getElementsByClassName("bar");
    let largest = i;
    let left = 2 * i + 1;
    let right = 2 * i + 2;
    if (left < n && array[left] > array[largest]) {
      largest = left;
    }
    if (right < n && array[right] > array[largest]) {
      largest = right;
    }
    if (largest != i) {
      await swap(array, i, largest, bars);
      await heapify(array, n, largest);
    }
}

//Radix Sort
async function countSorter(arr, n, exp) {
  let output = new Array(n);
  let i;
  let count = new Array(10);
  for (let i = 0; i < 10; i++) count[i] = 0;

  for (i = 0; i < n; i++) count[Math.floor(arr[i] / exp) % 10]++;
  for (i = 1; i < 10; i++) count[i] += count[i - 1];

  for (i = n - 1; i >= 0; i--) {
    output[count[Math.floor(arr[i] / exp) % 10] - 1] = arr[i];
    count[Math.floor(arr[i] / exp) % 10]--;
  }

  for (i = 0; i < n; i++) {
    arr[i] = output[i];
    await colorChange(arr, i);
  }
  return new Promise((resolve) => {
    resolve();
  });
}

export async function radixSort(arr, n) {
  let m = Math.max(...arr);
  for (let exp = 1; Math.floor(m / exp) > 0; exp *= 10) {
    await countSorter(arr, n, exp);
  }
}


//Modified Quick Sort
async function partitioner(arr, low, high) {
    let pivot = arr[high];
    let i = low - 1;
    bars[high].style.backgroundColor = "red";
    for (let j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            await swap(arr, i, j);
        }
    }
    await swap(arr, i + 1, high);
    bars[high].style.backgroundColor = "green";
    return new Promise((resolve) => {
        resolve(i + 1);
    });
}
async function quickSorter(arr, low, high) {
    let k = 8;
    if (low < high && high - low > k) {
        let pi = await partitioner(arr, low, high);
        await quickSorter(arr, low, pi - 1);
        await quickSorter(arr, pi + 1, high);
    }
    return new Promise((resolve) => resolve(arr));
}
export async function MQS(arr, low, high) {
    await quickSorter(arr, low, high);
    insertionSort(arr);
}

